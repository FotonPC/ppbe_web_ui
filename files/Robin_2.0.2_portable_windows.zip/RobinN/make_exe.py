import sys, os

def main(filename):
    fc = os.system(f'''masm32\\bin\\ml /c /coff {filename}''')
    fc2 = os.system(f'masm32\\bin\\link /subsystem:console {filename.split(".")[0]}.obj')
    if fc == fc2 == 0:
        print('[Все прошло успешно]')
        print('['+filename.split(".")[0]+".exe"+']')
    else:
        print('[Ошибка сборки OBJ файла]')

if __name__ == '__main__':
    if len(sys.argv) < 2:
        filename = input()
    else:
        filename = sys.argv[1]
    fc = os.system(f'''masm32\\bin\\ml /c /coff {filename}''')
    fc2 = os.system(f'masm32\\bin\\link /subsystem:console {filename.split(".")[0]}.obj')
    if fc == 0:
        print('[Все прошло успешно]')
        print('['+filename.split(".")[0]+".exe"+']')
    else:
        print('[MASM ROBIN FAILURE]')
