import zipfile
import os
battles={"Ледовое побоище":"ïÑñ«ó«Ñ »«í«¿ΘÑ",
"Синопское сражение":"æ¿¡«»ß¬«Ñ ßαáªÑ¡¿Ñ",
"Полтавская битва":"Å«½Γáóß¬á∩ í¿Γóá",
'Куликовская битва':'èπ½¿¬«óß¬á∩ í¿Γóá',
'Операция Буря в пустыне':'Ä»Ñαáµ¿∩ üπα∩ ó »πßΓδ¡Ñ',
'Сталинградская битва':'æΓá½¿¡úαáñß¬á∩ í¿Γóá',
'Цусимское сражение':'ûπß¿¼ß¬«Ñ ßαáªÑ¡¿Ñ',
'Курская битва':'èπαß¬á∩ í¿Γóá',
'Взятие Казани':'éº∩Γ¿Ñ èáºá¡¿',
'Взятие Константинополя':'éº∩Γ¿Ñ è«¡ßΓá¡Γ¿¡«»«½∩',
'Бородино':'ü«α«ñ¿¡«',
'Осада Измаила':'Äßáñá êº¼á¿½á',
'Битва народов':'ü¿Γóá ¡áα«ñ«ó',
'Битва при Ватерлоо':'ü¿Γóá »α¿ éáΓÑα½««',
'Бои при Халкин-Голе':'ü«¿ »α¿ òá½¬¿¡-â«½Ñ',
'Шипка':'ÿ¿»¬á',
'Фермопилы':'öÑα¼«»¿½δ',
'Переход Суворова через Альпы':'ÅÑαÑσ«ñ æπó«α«óá τÑαÑº Ç½∞»δ'}
bk,bv=battles.keys(),battles.values()
battles=dict(zip(bk,bv))
battlem={'åπ¬«ó':'Жуков',
"èπΓπº«ó":'Кутузов',
"ìá»«½Ñ«¡":'Наполеон',
"öÑñ«α ôΦá¬«ó":'Федор Ушаков'}
print("INFO",1,"install start")
os.rename(".fotonarchive","fa.zip")
print("INFO",2,"rename archive file")
z = zipfile.ZipFile('fa.zip', 'r')
print("INFO",3,"open archive file")
z.extractall()
print("INFO",4,"extract archive file")
z.close()
print("INFO",5,"close archive file")
os.remove("fa.zip")
print("INFO",6,"remove archive file")
print("ZIP ARCHIVE IS VERY**32 BAD. IT IS POLNOE GAVNO!")
for zip_gavno in battles.keys():
    zg=zip_gavno
    os.rename("Cartoteka/data/Battles/"+battles[zg]+".txt","Cartoteka/data/Battles/"+zg+".txt")    
print("INFO",7,'renamed battles data files')
for zip_gavno in battlem.keys():
    zg=zip_gavno
    os.rename("Cartoteka/data/Battleman/"+zg+".txt","Cartoteka/data/Battleman/"+battlem[zg]+".txt")
print("INFO",8,'renamed warriors data files')
import winshell
from win32com.client import Dispatch
 
desktop = winshell.desktop()
path = os.path.join(desktop, "Cartoteka.lnk")
target = os.getcwd()+r"\Cartoteka\Cartoteka.exe"
wDir = os.getcwd()+r"\Cartoteka"
icon = os.getcwd()+r"\Cartoteka\Cartoteka.exe"
 
shell = Dispatch('WScript.Shell')
shortcut = shell.CreateShortCut(path)
shortcut.Targetpath = target
shortcut.WorkingDirectory = wDir
shortcut.IconLocation = icon
shortcut.save()
print("INFO",9,'made shortcut')
print("INFO",10,"INSTALL FINICHED")
input("Press ENTER to close window _")
