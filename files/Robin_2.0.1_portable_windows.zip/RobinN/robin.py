import sys, parse, ro_asm_compiler, make_exe, imp_lexer, subprocess

if __name__ == '__main__':
    if len(sys.argv) != 2:
        filename = input('Введите название файла:')
    else:
        filename = sys.argv[1]
    text = open(filename, encoding='utf-8').read()
    print('[Программа загружена]')
    tokens = imp_lexer.imp_lex(text)
    print(tokens)
    print('[Программа лексирована]')
    #print(tokens)
    parse_result = parse.Statement(tokens=tokens)
    print('[Программа распарсена]')
    robin_assembler = ro_asm_compiler.make_asm(parse_result)
    print('[Программа собрана в MASM]')
    print(robin_assembler)
    with open(filename.split('.')[0]+'.masm', 'w+') as f:
        f.write(robin_assembler)
    print(f'[Файл "{filename.split(".")[0]+".masm"}" создан]')
    make_exe.main(filename.split(".")[0]+".masm")
    print('[Программа запущена]')
    subprocess.call([filename.split(".")[0]+".exe"])
    input('Программа завершена')

